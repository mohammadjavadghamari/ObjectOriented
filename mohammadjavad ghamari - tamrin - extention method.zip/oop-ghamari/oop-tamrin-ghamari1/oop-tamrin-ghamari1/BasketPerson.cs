﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop_tamrin_ghamari1
{
    public static class BasketPerson
    {
        public static string GetFullMahsol(this Basket basket)
        {
            return $"{basket.Mahsol} - {basket.Tedad} - {basket.Price}";
        }
    }
}
