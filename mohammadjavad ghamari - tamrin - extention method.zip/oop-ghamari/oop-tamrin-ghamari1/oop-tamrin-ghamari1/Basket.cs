﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop_tamrin_ghamari1
{
    public class Basket
    {
        

        public int Id { get; set; }
        public string Mahsol { get; set; }
        public string Tedad { get; set; }
        public string Price { get; set; }
    
}
}
