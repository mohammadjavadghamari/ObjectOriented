namespace oop_tamrin_ghamari1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var obj = new Person { Name = "javad", Family = "ghamari", Age = "22" };

            string bb = obj.GetFullName();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var obj1 = new Basket { Mahsol = "iphone 13", Tedad = "1", Price = "1000$" };
            string bb1 = obj1.GetFullMahsol();
        }
    }
}
